package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.DatabaseOperations;
import bean.AdminInfoBean;


public class admindate extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public admindate() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession hs=request.getSession();
		if(hs.getAttribute("adname")==null||hs.getAttribute("name")==null) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		String id =request.getParameter("id");
		int page=Integer.parseInt(id == null || "".equals(id)?"1":id);
		DatabaseOperations dbo =new DatabaseOperations();
			int count =dbo.adcount();
			if((count/10)<=(page))page=count/10-1;
			if(page<=0)page=1;
			int size=10;
			page=(page-1)*10;
				List<AdminInfoBean>ub=dbo.selectadmin(page,size);
				request.setAttribute("ub", ub);
				count=count/10+1;
				request.setAttribute("count", count);
				request.getRequestDispatcher("admin.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
