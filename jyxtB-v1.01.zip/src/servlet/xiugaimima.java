package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Dao.DatabaseOperations;
import bean.UserInfoBean;


public class xiugaimima extends HttpServlet {


    public xiugaimima() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserInfoBean user=new UserInfoBean();
		HttpSession s =request.getSession();
		if(s.getAttribute("name")==null||s.getAttribute("name")==null) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		user.setUname(s.getAttribute("name").toString());
		user.setPassword((String)request.getParameter("lopassword"));
		DatabaseOperations dbo=new DatabaseOperations();
		int pf=dbo.jyxtlogin(user);
		if(pf>0) {
			if(request.getParameter("newPassword").equals(request.getParameter("newpasswords"))) {
				user.setPassword(request.getParameter("newPassword"));
				dbo.passwordupdate(user);
			}
		}
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
