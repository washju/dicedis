package Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.AdminInfoBean;
import bean.UserInfoBean;

public class DatabaseOperations {
	public int jyxtlogin(UserInfoBean user) {
		String sql ="select * from userinfo where uname=? and password =?";
		Object[] a= {user.getUname(),user.getPassword()};
		int pf=GeneralDatabaseOperations.Generalqurycount(sql,a.length,a);
		System.out.println(user.getUname()+"-----"+user.getPassword());
		return pf;
	}
	public int adminlogin(AdminInfoBean admin) {
		String sql ="select * from adminlnfo where name=? and password =?";
		Object[] a= {admin.getName(),admin.getPassword()};
		int pf=GeneralDatabaseOperations.Generalqurycount(sql,a.length,a);
		return pf;
	}
	public int jyxtreg(UserInfoBean user) {
		String sql="INSERT INTO userinfo(uname,password,phone) VALUES(?,?,?)";
		Object[] a= {user.getUname(),user.getPassword(),user.getPhone()};
		int pf;
		String sqls="select * from userinfo where uname=?";
		int xx=GeneralDatabaseOperations.Generalqurycount(sqls,1,a);
		if(xx<=0){
		pf=GeneralDatabaseOperations.Generalupdate(sql,a.length,a);
		}else {
			pf=-5;
		}
		return pf;
	}
	public  int update(UserInfoBean user) {
		String sql="UPDATE userinfo set sex=?,age=?,phone=?,webchat=?,email =?,uinfo=?,pic=? where uname=?";
		Object a[]= {user.getSex(),user.getAge(),user.getPhone(),user.getWebchat(),user.getEmail(),user.getUinfo(),user.getPic(),user.getUname()};
		int pf=GeneralDatabaseOperations.Generalupdate(sql,a.length,a);
		return pf;
	}
	public int passwordupdate(UserInfoBean user) {
		String sql="UPDATE userinfo set password=? where uname=?";
		Object a[]= {user.getPassword(),user.getUname()};
		int pf=GeneralDatabaseOperations.Generalupdate(sql,a.length,a);
		return pf;
	}
	public int count() {
		String sql ="select * from userinfo";
		int pf=GeneralDatabaseOperations.Generalqurycounts(sql);
		return pf;
	}
	public int adcount() {
		String sql ="select * from adminlnfo";
		int pf=GeneralDatabaseOperations.Generalqurycounts(sql);
		return pf;
	}
	public List<UserInfoBean> selectghost(int page,int size) {
		String sql ="select * from userInfo limit ?,?";
		Object[] a= {page,size};
		ResultSet rs=GeneralDatabaseOperations.Generalqury(sql, a.length, a);
		List<UserInfoBean>UserBean =new ArrayList<>();
		try {
			while(rs.next()) {
				UserInfoBean b=new UserInfoBean();
				b.setUname(rs.getString("uname"));
				b.setAge(Integer.parseInt(rs.getString("age") == null || "".equals(rs.getString("age"))?"0":rs.getString("age")));
				b.setSex(rs.getString("sex"));
				b.setPhone(rs.getString("phone"));
				b.setWebchat(rs.getString("webchat"));
				b.setEmail(rs.getString("email"));
				b.setUinfo(rs.getString("uinfo"));
				b.setPic(rs.getString("pic"));
				UserBean.add(b);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			GeneralDatabaseOperations.allclose();
		}
		return UserBean ;
	}
	public List<AdminInfoBean> selectadmin(int page,int size) {
		String sql ="select * from adminlnfo limit ?,?";
		Object[] a= {page,size};
		ResultSet rs=GeneralDatabaseOperations.Generalqury(sql, a.length, a);
		List<AdminInfoBean>UserBean =new ArrayList<>();
		try {
			while(rs.next()) {
				AdminInfoBean ad=new AdminInfoBean();
				ad.setName(rs.getString("name"));
				ad.setRole(rs.getString("role"));
				UserBean.add(ad);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			GeneralDatabaseOperations.allclose();
		}
		return UserBean ;
	}
	public UserInfoBean ghostupdate(Object name) {
		String sql ="select * from userInfo where uname=?";
		Object[] a= {name};
		ResultSet rs=GeneralDatabaseOperations.Generalqury(sql, a.length, a);
		UserInfoBean b =new UserInfoBean();
		try {
			while(rs.next()) {
				b.setAge(Integer.parseInt(rs.getString("age") == null || "".equals(rs.getString("age"))?"0":rs.getString("age")));
				b.setSex(rs.getString("sex"));
				b.setPhone(rs.getString("phone"));
				b.setWebchat(rs.getString("webchat"));
				b.setEmail(rs.getString("email"));
				b.setUinfo(rs.getString("uinfo"));
				b.setPic(rs.getString("pic"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			GeneralDatabaseOperations.allclose();
		}
		return b ;
	}

}
