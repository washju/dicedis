package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.DatabaseOperations;
import bean.UserInfoBean;


public class ghostdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public ghostdate() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession hs=request.getSession();
		if(hs.getAttribute("adname")==null||hs.getAttribute("name")==null) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		request.setCharacterEncoding("utf-8");
		String id =request.getParameter("id");
		int page=Integer.parseInt(id == null || "".equals(id)?"1":id);
		DatabaseOperations dbo =new DatabaseOperations();
			int count =dbo.count();
			if((count/10)<=(page))page=count/10-1;
			if(page<=0)page=1;
			int size=10;
			page=(page-1)*10;
				List<UserInfoBean>ub=dbo.selectghost(page,size);
				request.setAttribute("ub", ub);
				count=count/10+1;
				request.setAttribute("count", count);
				request.getRequestDispatcher("ghostdate.jsp").forward(request, response);
				
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
