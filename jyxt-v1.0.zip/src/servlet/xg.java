package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.DatabaseOperations;
import bean.UserInfoBean;


public class xg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public xg() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession hs=request.getSession();
		if(hs.getAttribute("adname")==null||hs.getAttribute("name")==null) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		DatabaseOperations dbo=new DatabaseOperations();
		String name = hs.getAttribute("name").toString();
		System.out.println("name");
		UserInfoBean u=dbo.ghostupdate(name);
		request.setAttribute("u", u);
		request.getRequestDispatcher("xiugai.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
