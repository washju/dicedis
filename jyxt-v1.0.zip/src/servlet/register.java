package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.DatabaseOperations;
import bean.UserInfoBean;


public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public register() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserInfoBean user=new UserInfoBean();
		HttpSession hs=request.getSession();
		if(hs.getAttribute("adname")==null||hs.getAttribute("name")==null) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		user.setUname((String)request.getParameter("uname"));
		user.setPassword((String)request.getParameter("password"));
		user.setPhone((String)request.getParameter("phone"));
		DatabaseOperations dbo=new DatabaseOperations();
		int pf=dbo.jyxtreg(user);
		if(pf>0) {
			response.sendRedirect("login.jsp");
		}else {
			request.setAttribute("pf",pf);
			request.getRequestDispatcher("Register.jsp").forward(request, response);
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
