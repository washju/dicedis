package servlet;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import Dao.DatabaseOperations;
import bean.UserInfoBean;


public class xiugai extends HttpServlet {

       
 
    public xiugai() {
    	
    	
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		UserInfoBean user = new UserInfoBean();
		HttpSession s =request.getSession();
		if(s.getAttribute("adname")==null||s.getAttribute("name")==null) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		user.setUname(s.getAttribute("name").toString());
		if(ServletFileUpload.isMultipartContent(request)) {
			FileItemFactory fa  =new DiskFileItemFactory();
			ServletFileUpload upload=new ServletFileUpload(fa);
			try {
				List <FileItem>items=upload.parseRequest(request);
				Iterator<FileItem>it=items.iterator();
				while(it.hasNext()) {
					FileItem item =it.next();
					if(item.isFormField()){
						
						 if(item.getFieldName().equals("sex")) {
							 user.setSex(item.getString());
						}else if(item.getFieldName().equals("age")) {
							
							user.setAge(Integer.parseInt(item.getString()== null || "".equals(item.getString())?"0":item.getString()));
								}
						else if(item.getFieldName().equals("Phone")) {
							 user.setPhone(item.getString());
							 System.out.print(user.getPhone());
						}else if(item.getFieldName().equals("webchat")) {
							 user.setWebchat(item.getString());
						}else if(item.getFieldName().equals("email")) {
							 user.setEmail(item.getString());
						}else if(item.getFieldName().equals("uinfo")) {
							 user.setUinfo(item.getString());
							}
					}else {
							
							String filename=item.getName();
							if(!filename.equals("")) {
								String ext=filename;
								user.setPic(ext);
								while(ext.indexOf(".")!=-1) {
									ext=ext.substring(ext.indexOf(".")+1);
								}
								if(!(ext.equals("jpg")||ext.equals("png")||ext.equals("gif")||ext.equals("jpeg")||ext.equals("bmp"))) {
									continue ;
								
								}
								String path=getServletContext().getRealPath("/friend/img/pic"); 
								File file=new File(path);  
								 if (!file.exists() && !file.isDirectory())file.mkdir();
						
								user.setPic(filename);
								File jpgfile=new File(path,user.getUname()+"."+ext);
								try {
									item.write(jpgfile);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							
						
						}
					
				}
				
			} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		DatabaseOperations dbo=new DatabaseOperations();
		int pf=dbo.update(user);
		request.setAttribute("pf", pf);
		request.getRequestDispatcher("xiugai.jsp").forward(request, response);
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
