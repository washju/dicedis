package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.DatabaseOperations;
import bean.AdminInfoBean;

public class adminlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public adminlogin() {
        super();

    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AdminInfoBean admin=new AdminInfoBean();
		admin.setName((String)request.getParameter("uname"));
		admin.setPassword((String)request.getParameter("upassword"));
		DatabaseOperations dbo=new DatabaseOperations();
		int pf=dbo.adminlogin(admin);

		if(pf>0) {
			Cookie cookie=new Cookie("aduser",admin.getName());
			response.addCookie(cookie);
			HttpSession se=request.getSession();
			se.setAttribute("adname", admin.getName());
			response.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			response.sendRedirect("manage.jsp");
		}
		else {
		
			request.setAttribute("name",admin.getName());	
			request.setCharacterEncoding("utf-8");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
