package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GeneralDatabaseOperations {
	private static String url="jdbc:mysql://127.0.0.1:3306/jyxt?useSSL=false";
	private static String user="root";
	private static String password="?????????????????????";
	private static Connection connection=null;
	private static PreparedStatement Preparedstatement=null;
	private static ResultSet resultSet=null;
	public GeneralDatabaseOperations() {
		
	}
	public static ResultSet Generalqury(String sql,int num,Object[]a) {
		
		try {
		Connect();
		Preparedstatement=connection.prepareStatement(sql);
		for(int i=0;i<num;i++) {
			Preparedstatement.setObject(i+1, a[i]);
		}
		resultSet=Preparedstatement.executeQuery();
		return resultSet;
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultSet;
	}
	public static int Generalqurycount(String sql,int num,Object[]a) {
		int count=0;
		try {
			Connect();
			Preparedstatement=connection.prepareStatement(sql);
			for(int i=0;i<num;i++) {
				Preparedstatement.setObject(i+1, a[i]);
			}
			resultSet=Preparedstatement.executeQuery();
			while(resultSet.next()) {
				count++;
			}
			return count;
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
			return -1;
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
			return -2;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return -3;
		}
	}
	public static int Generalqurycounts(String sql) {
		int count=0;
		try {
			Connect();
			Preparedstatement=connection.prepareStatement(sql);
			resultSet=Preparedstatement.executeQuery();
			while(resultSet.next()) {
				count++;
			}
			return count;
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
			return -1;
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
			return -2;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return -3;
		}
	}
	public static int Generalupdate(String sql,int num,Object[]a){
		int count=-1;
		try {
			Connect();
			Preparedstatement=connection.prepareStatement(sql);
			for(int i=0;i<num;i++) {
				Preparedstatement.setObject(i+1, a[i]);
			}
			count=Preparedstatement.executeUpdate();
			return count;
		}catch(ClassNotFoundException e){
			e.printStackTrace();
			return -2;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -3;
		}catch(Exception e){
			e.printStackTrace();
			return -4;
		}finally {
			allclose();
		}	
	}
	public static void Connect() throws SQLException, ClassNotFoundException {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection(url, user, password);
	}
	public static void allclose() {
			try {
				if(resultSet!=null)resultSet.close();
				if(Preparedstatement!=null)Preparedstatement.close();
				if(connection!=null)connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
}
