package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.DatabaseOperations;
import bean.UserInfoBean;


public class adxg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public adxg() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DatabaseOperations dbo=new DatabaseOperations();
		HttpSession hs=request.getSession();
		if(hs.getAttribute("adname")==null||hs.getAttribute("adname")==null) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		String name =request.getParameter("name").toString();
		UserInfoBean u=dbo.ghostupdate(name);
		request.setAttribute("u", u);
		request.setAttribute("name", name);
		request.getRequestDispatcher("xiugai.jsp").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
